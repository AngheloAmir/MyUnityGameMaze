using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SkillPlatform : MonoBehaviour
{
    [SerializeField] int delayToVanish;
    [SerializeField] int duration;
    int vanish;
    int dur;
    bool isVanish;

    void Start()
    {
        vanish = delayToVanish;
        dur = 0;
        isVanish = false;
    }

    // Update is called once per frame

    private void FixedUpdate()
    {
        if(isVanish)
        {
            if (dur >= 0)
                dur--;
            else
            {
                isVanish = false;
                vanish = delayToVanish;
                GetComponent<Renderer>().enabled = true;
                GetComponent<BoxCollider>().enabled = true;
            }
        }
        else
        {
            if (vanish >= 0)
                vanish--;
            else
            {
                isVanish = true;
                dur = duration;
                GetComponent<Renderer>().enabled = false;
                GetComponent<BoxCollider>().enabled = false;
            }
        }
    }
}
