using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class PlayerBehavior : MonoBehaviour
{
    public static int currentKeyCount;

    [SerializeField] public float speed = 6.0F;
    [SerializeField] public int numberOfKeys = 5;

    CharacterController controller;
    float gravity = 20.0F;
    private Vector3 moveDirection = Vector3.zero;

    void Start()
    {
        controller = GetComponent<CharacterController>();
        currentKeyCount = numberOfKeys;
    }

    void Update()
    {
        if (transform.position.y <= -2f)
        {
            controller.velocity.Set(0, 0, 0);
            transform.position = new Vector3(-11, 3, 0.326f);
            return;
        }
        if (controller.isGrounded)
        {
            moveDirection = new Vector3(Input.GetAxis("Horizontal"), 0, Input.GetAxis("Vertical"));
            moveDirection = transform.TransformDirection(moveDirection);
            moveDirection *= speed;
            //if (Input.GetButton("Jump"))
                //moveDirection.y = jumpSpeed;
        }
        moveDirection.y -= gravity * Time.deltaTime;
        controller.Move(moveDirection * Time.deltaTime);

        if(Input.GetKeyUp(KeyCode.R))
        {
            SceneManager.LoadSceneAsync(SceneManager.GetActiveScene().buildIndex);
        }

        if (Input.GetKey("escape"))
        {
            Application.Quit();
            Debug.Log("Quiting");
        }
    }

    private void OnTriggerEnter(Collider other)
    {
        if (other.gameObject.layer == 6)
        {
            Destroy(other.gameObject);
            currentKeyCount--;
        }
    }
}
