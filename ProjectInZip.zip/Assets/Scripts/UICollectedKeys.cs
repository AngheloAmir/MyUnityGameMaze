using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class UICollectedKeys : MonoBehaviour
{
    [SerializeField] Text myText;

    void Update()
    {
        if(PlayerBehavior.currentKeyCount <= 0)
            myText.text = "Congratstulation! You have finish the GAME!";
        else
            myText.text = "Remain keys to collect: " + PlayerBehavior.currentKeyCount.ToString();
    }
}
